/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shaorinsamaira
 */

import java.util.Scanner;

public class QUESTION5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a, b, c, d, e, f: ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();
        double d = scanner.nextDouble();
        double e = scanner.nextDouble();
        double f = scanner.nextDouble();
        
      
        //Calculate the denominator 
        double denominator = (a * d) - (b * c);
        
        
        // Check whether the Deno is zero 
        if (denominator == 0) {
            System.out.println("The equation has no solution");
        } else {
            // calculate X using the given formula 
            double x = ((e * d) - (b * f)) / denominator;
            // calculate Y using the given formula 
            double y = ((a * f) - (e * c)) / denominator;
            
            // Display the answer to two decimal places 
            System.out.printf("x = %.2f, y = %.2f%n", x, y);
        }

        scanner.close();
    }

}
