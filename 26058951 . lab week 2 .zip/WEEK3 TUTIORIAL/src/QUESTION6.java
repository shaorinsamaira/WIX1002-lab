/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shaorinsamaira
 */

import java.util.Scanner;

public class QUESTION6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();

        System.out.print("Enter the coordinate point (x y): ");
        double x = scanner.nextDouble();
        double y = scanner.nextDouble();

        // Calculate distance from origin (0,0) squared to avoid unnecessary sqrt precision issues, 
        // or use Math.sqrt(x * x + y * y)
        double distanceSquared = (x * x) + (y * y);
        double radiusSquared = radius * radius;

        if (distanceSquared < radiusSquared) {
            System.out.println("The point  is inside the circle.");
        } else {
            System.out.println("The point  is outside the circle.");
        }

        scanner.close();
    }
}
