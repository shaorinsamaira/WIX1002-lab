/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shaorinsamaira
 */

import java.util.Scanner;

public class QUESTION3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the sales volume: ");
        double salesVolume = scanner.nextDouble();
        double commissionRate;
        double commission;

        if (salesVolume <= 100) {
            commissionRate = 0.05;
        } else if (salesVolume <= 500) {
          
            commissionRate = 0.075;
        } else if (salesVolume <= 1000) {
            commissionRate = 0.10;
        } else {
            commissionRate = 0.125;
        }

        commission = salesVolume * commissionRate;
        System.out.printf("The commission is: %.2f%n", commission);

        scanner.close();
    }
    
}
